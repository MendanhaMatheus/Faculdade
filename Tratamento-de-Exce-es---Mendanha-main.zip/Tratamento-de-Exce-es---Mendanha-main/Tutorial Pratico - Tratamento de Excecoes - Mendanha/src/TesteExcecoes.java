public class TesteExcecoes {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria(500.00);
        System.out.println("Saldo inicial: R$ " + String.format("%.2f", conta.getSaldo()));

        System.out.println("\n--- Tentativa: Depósito Válido (R$ 100.00) ---");
        try {
            conta.depositar(100.00);
            System.out.println("Depósito bem-sucedido.");
        } catch (ValorInvalidoException e) {
            System.out.println("Erro ao depositar: " + e.getMessage());
        } finally {
            System.out.println("Operação 1 finalizada. Saldo: R$ " + String.format("%.2f", conta.getSaldo()));
        }

        System.out.println("\n--- Tentativa: Depósito Inválido (R$ -50.00) ---");
        try {
            conta.depositar(-50.00);
            System.out.println("Depósito bem-sucedido.");
        } catch (ValorInvalidoException e) {
            System.out.println("Erro ao depositar: " + e.getMessage());
        } finally {
            System.out.println("Operação 2 finalizada. Saldo: R$ " + String.format("%.2f", conta.getSaldo()));
        }

        System.out.println("\n--- Tentativa: Saque Inválido (R$ 1000.00) ---");
        try {
            conta.sacar(1000.00);
            System.out.println("Saque bem-sucedido.");
        } catch (ValorInvalidoException e) {
            System.out.println("Erro ao sacar (valor inválido): " + e.getMessage());
        } catch (SaldoInsuficienteException e) {
            System.out.println("Erro ao sacar (saldo): " + e.getMessage());
        } finally {
            System.out.println("Operação 3 finalizada. Saldo: R$ " + String.format("%.2f", conta.getSaldo()));
        }

        System.out.println("\n--- Tentativa: Saque Válido (R$ 200.00) ---");
        try {
            conta.sacar(200.00);
            System.out.println("Saque bem-sucedido.");
        } catch (ValorInvalidoException | SaldoInsuficienteException e) {
            System.out.println("Erro ao sacar: " + e.getMessage());
        } finally {
            System.out.println("Operação 4 finalizada. Saldo: R$ " + String.format("%.2f", conta.getSaldo()));
        }
    }
}