public class ContaBancaria {
    private double saldo;

    public ContaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public double getSaldo() {
        return saldo;
    }

    public void depositar(double valor) throws ValorInvalidoException {
        if (valor <= 0) {
            throw new ValorInvalidoException("O valor do depósito deve ser positivo.");
        }
        this.saldo += valor;
        System.out.println("Depósito de R$ " + String.format("%.2f", valor) + " realizado. Saldo atual: R$ " + String.format("%.2f", saldo));
    }

    public void sacar(double valor) throws ValorInvalidoException, SaldoInsuficienteException {
        if (valor <= 0) {
            throw new ValorInvalidoException("O valor do saque deve ser positivo.");
        }

        if (valor > this.saldo) {
            throw new SaldoInsuficienteException("Saldo insuficiente. Saldo: R$ " + String.format("%.2f", saldo) + ", Saque: R$ " + String.format("%.2f", valor));
        }

        this.saldo -= valor;
        System.out.println("Saque de R$ " + String.format("%.2f", valor) + " realizado. Saldo atual: R$ " + String.format("%.2f", saldo));
    }
}