import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class Transacao
{
    private String tipo;
    private double valor;
    private LocalDateTime data;
    public Transacao(String tipo, double valor)
    {
        this.tipo=tipo;
        this.valor=valor;
        this.data=LocalDateTime.now();
    }
    @Override
    public String toString()
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String valorFormatado = String.format("R$ %.2f", valor);
        return "[" + data.format(formatter) + "] " + tipo + ": " + valorFormatado;
    }
}