import java.util.ArrayList;
public class ContaBancaria
{
    private String numeroConta;
    private double saldo;
    private Usuario titular;
    private String tipoConta;
    private ArrayList<Transacao> extrato;
    public ContaBancaria(String numeroConta, Usuario titular, String tipoConta)
    {
        this.numeroConta = numeroConta;
        this.titular = titular;
        this.tipoConta = tipoConta;
        this.saldo = 0.0;
        this.extrato = new ArrayList<>();
    }
    public boolean depositar(double valor)
    {
        if(valor > 0)
        {
            this.saldo += valor;
            this.extrato.add(new Transacao("Depósito", valor));
            return true;
        }
        return false;
    }
    public boolean sacar(double valor)
    {
        if(valor > 0 && valor <= this.saldo)
        {
            this.saldo -= valor;
            this.extrato.add(new Transacao("Saque", valor));
            return true;
        }
        return false;
    }
    public void consultarExtrato()
    {
        System.out.println("\n--- Extrato da Conta " + this.numeroConta + " (" + this.tipoConta + ") ---");
        System.out.println("Titular: " + this.titular.getNome());
        for(Transacao t : this.extrato)
        {
            System.out.println(t);
        }
        System.out.println("----------------------------------------");
        System.out.printf("Saldo Atual: R$ %.2f\n", this.saldo);
    }
    public String getNumeroConta() {
        return numeroConta;
    }
    public double getSaldo()
    {
        return saldo;
    }
    public Usuario getTitular()
    {
        return titular;
    }
    public String getTipoConta()
    {
        return tipoConta;
    }
    @Override
    public String toString()
    {
        return "Conta " + tipoConta + " Nº " + numeroConta +
                " (Titular: " + titular.getNome() +
                " - Saldo: R$ " + String.format("%.2f", saldo) + ")";
    }
}