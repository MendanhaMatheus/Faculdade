public class Main
{
    public static void main(String[] args)
    {
        Banco meuBanco=new Banco();
        Usuario u1 = meuBanco.criarUsuario("Matheus Mendanha", "111.111.111-11");
        ContaBancaria c1 = meuBanco.criarConta("1001", u1.getCpf(), "Corrente");
        c1.depositar(1500.00);
        c1.sacar(200.00);
        Usuario u2 = meuBanco.criarUsuario("Matias Mendonca", "222.222.222-22");
        ContaBancaria c2 = meuBanco.criarConta("1002", u2.getCpf(), "Poupança");
        c2.depositar(800.50);
        c2.sacar(100.00);
        Usuario u3 = meuBanco.criarUsuario("Carlao du Grau", "333.333.333-33");
        ContaBancaria c3_1 = meuBanco.criarConta("1003", u3.getCpf(), "Corrente");
        ContaBancaria c3_2 = meuBanco.criarConta("1004", u3.getCpf(), "Investimento");
        c3_1.depositar(5000.00);
        c3_2.depositar(10000.00);
        c3_1.sacar(500.00);
        Usuario u4 = meuBanco.criarUsuario("Jonas Pato", "444.444.444-44");
        ContaBancaria c4_1 = meuBanco.criarConta("1005", u4.getCpf(), "Corrente");
        ContaBancaria c4_2 = meuBanco.criarConta("1006", u4.getCpf(), "Poupança");
        c4_1.depositar(1200.00);
        c4_2.depositar(3000.00);
        c4_1.sacar(100.00);
        c4_2.sacar(300.00);
        Usuario u5 = meuBanco.criarUsuario("Hello Word da Silva", "555.555.555-55");
        ContaBancaria c5_1 = meuBanco.criarConta("1007", u5.getCpf(), "Corrente");
        ContaBancaria c5_2 = meuBanco.criarConta("1008", u5.getCpf(), "Poupança");
        ContaBancaria c5_3 = meuBanco.criarConta("1009", u5.getCpf(), "Empresarial");
        c5_1.depositar(10000.00);
        c5_2.depositar(25000.00);
        c5_3.depositar(150000.00);
        c5_1.sacar(1000.00);
        c5_3.sacar(20000.00);
        meuBanco.listarTodasContas();
        meuBanco.listarContasPorCPF("444.444.444-44");
        meuBanco.listarContasPorCPF("555.555.555-55");
        c5_1.consultarExtrato();
    }
}