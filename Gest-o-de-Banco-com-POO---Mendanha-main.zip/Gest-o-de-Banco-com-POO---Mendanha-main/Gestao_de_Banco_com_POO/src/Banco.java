import java.util.ArrayList;
public class Banco
{
    private ArrayList<Usuario> usuarios;
    private ArrayList<ContaBancaria> contas;
    public Banco()
    {
        this.usuarios = new ArrayList<>();
        this.contas = new ArrayList<>();
    }
    public Usuario criarUsuario(String nome, String cpf)
    {
        Usuario novoUsuario = new Usuario(nome, cpf);
        this.usuarios.add(novoUsuario);
        System.out.println("Usuário criado: " + nome);
        return novoUsuario;
    }
    public Usuario buscarUsuarioPorCPF(String cpf)
    {
        for(Usuario u : usuarios)
        {
            if(u.getCpf().equals(cpf))
            {
                return u;
            }
        }
        return null;
    }
    public ContaBancaria criarConta(String numeroConta, String cpfTitular, String tipoConta)
    {
        Usuario titular = buscarUsuarioPorCPF(cpfTitular);
        if(titular != null)
        {
            ContaBancaria novaConta = new ContaBancaria(numeroConta, titular, tipoConta);
            this.contas.add(novaConta);
            System.out.println("Conta " + tipoConta + " " + numeroConta + " criada para " + titular.getNome());
            return novaConta;
        } else {
            System.out.println("Erro!!! CPF " + cpfTitular + " não encontrado. Conta não criada.");
            return null;
        }
    }
    public ContaBancaria buscarContaPorNumero(String numeroConta)
    {
        for(ContaBancaria c : contas)
        {
            if(c.getNumeroConta().equals(numeroConta))
            {
                return c;
            }
        }
        return null;
    }
    public void listarTodasContas()
    {
        System.out.println("\n--- LISTA DE TODAS AS CONTAS DO BANCO ---");
        if(contas.isEmpty())
        {
            System.out.println("Nenhuma conta cadastrada!!!!!!!");
            return;
        }
        for(ContaBancaria c : contas)
        {
            System.out.println(c);
        }
    }
    public void listarContasPorCPF(String cpf)
    {
        Usuario titular = buscarUsuarioPorCPF(cpf);
        if (titular == null)
        {
            System.out.println("!!!!!!!!Nenhum usuário encontrado com o CPF: " + cpf);
            return;
        }
        System.out.println("\n--- CONTAS DO CLIENTE: " + titular.getNome() + " (CPF: " + cpf + ") ---");
        boolean encontrouConta = false;
        for(ContaBancaria c : contas)
        {
            if(c.getTitular().getCpf().equals(cpf))
            {
                System.out.println(c);
                encontrouConta = true;
            }
        }
        if (!encontrouConta)
        {
            System.out.println("!!!!!!!!!!Nenhuma conta encontrada para este usuário.");
        }
    }
}