import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
public class ContaBancaria
{
    private String numeroConta;
    private double saldo;
    private String tipoConta;
    private ArrayList<String> extrato;
    public ContaBancaria(String numeroConta, String tipoConta) {
        this.numeroConta = numeroConta;
        this.tipoConta = tipoConta;
        this.saldo = 0.0;
        this.extrato = new ArrayList<>();
    }
    private String formatarTransacao(String tipo, double valor) {
        LocalDateTime data = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String valorFormatado = String.format("R$ %.2f", valor);
        return "[" + data.format(formatter) + "] " + tipo + ": " + valorFormatado;
    }
    public boolean depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
            this.extrato.add(formatarTransacao("Depósito", valor));
            return true;
        }
        return false;
    }
    public boolean sacar(double valor) {
        if (valor > 0 && valor <= this.saldo) {
            this.saldo -= valor;
            this.extrato.add(formatarTransacao("Saque", valor));
            return true;
        }
        return false;
    }
    public void consultarExtrato() {
        System.out.println("\n--- Extrato da Conta " + this.numeroConta + " (" + this.tipoConta + ") ---");
        for (String t : this.extrato) {
            System.out.println(t);
        }
        System.out.println("----------------------------------------");
        System.out.printf("Saldo Atual: R$ %.2f\n", this.saldo);
    }
    public String getNumeroConta() {
        return numeroConta;
    }
    public double getSaldo() {
        return saldo;
    }
    public String getTipoConta() {
        return tipoConta;
    }
    @Override
    public String toString() {
        return "Conta " + tipoConta + " Nº " + numeroConta +
                " (Saldo: R$ " + String.format("%.2f", saldo) + ")";
    }
}