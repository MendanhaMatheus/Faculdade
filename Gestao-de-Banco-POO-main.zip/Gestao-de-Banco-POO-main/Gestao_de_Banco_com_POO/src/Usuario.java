import java.util.ArrayList;

public class Usuario {
    private String nome;
    private String cpf;
    private ArrayList<ContaBancaria> contas;

    public Usuario(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
        this.contas = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void adicionarConta(ContaBancaria conta) {
        this.contas.add(conta);
    }

    public ArrayList<ContaBancaria> getContas() {
        return contas;
    }

    @Override
    public String toString()
    {
        return "Usuario [Nome: " + nome + ", CPF: " + cpf + "]";
    }
}