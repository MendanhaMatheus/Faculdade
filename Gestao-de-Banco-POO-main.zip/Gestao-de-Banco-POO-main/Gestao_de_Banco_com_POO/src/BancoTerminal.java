import java.util.ArrayList;
import java.util.Scanner;

public class BancoTerminal {

    private ArrayList<Usuario> usuarios;
    private Scanner scanner;

    public BancoTerminal() {
        this.usuarios = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        // Pré-cadastrar 1 usuário e 1 conta para facilitar testes
        Usuario u1 = new Usuario("Ana Silva", "111");
        ContaBancaria c1 = new ContaBancaria("1001", "Corrente");
        c1.depositar(1000.00);
        u1.adicionarConta(c1);
        this.usuarios.add(u1);
    }

    public void exibirMenu() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\nBEM-VINDO AO BANCO");
            System.out.println("1. Criar Usuário");
            System.out.println("2. Criar Conta Bancária");
            System.out.println("3. Depositar");
            System.out.println("4. Sacar");
            System.out.println("5. Consultar Extrato");
            System.out.println("6. Listar Contas por CPF");
            System.out.println("7. Listar Todas as Contas");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Erro: Opção inválida. Digite um número.");
                opcao = -1;
                continue;
            }

            switch (opcao) {
                case 1: criarUsuario(); break;
                case 2: criarConta(); break;
                case 3: realizarDeposito(); break;
                case 4: realizarSaque(); break;
                case 5: consultarExtrato(); break;
                case 6: listarContasPorCPF(); break;
                case 7: listarTodasContas(); break;
                case 0: System.out.println("Obrigado por usar nosso banco. Adeus!"); break;
                default: System.out.println("Opção inválida. Tente novamente.");
            }
        }
        scanner.close();
    }

    private Usuario buscarUsuarioPorCPF(String cpf) {
        for (Usuario u : usuarios) {
            if (u.getCpf().equals(cpf)) {
                return u;
            }
        }
        return null;
    }

    private ContaBancaria buscarContaGlobal(String numeroConta) {
        for (Usuario u : usuarios) {
            for (ContaBancaria c : u.getContas()) {
                if (c.getNumeroConta().equals(numeroConta)) {
                    return c;
                }
            }
        }
        return null;
    }

    private void criarUsuario() {
        System.out.print("Digite o nome do usuário: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o CPF do usuário: ");
        String cpf = scanner.nextLine();

        if (nome.isEmpty() || cpf.isEmpty()) {
            System.out.println("Erro: Nome e CPF não podem ser vazios.");
            return;
        }
        if (buscarUsuarioPorCPF(cpf) != null) {
            System.out.println("Erro: CPF já cadastrado.");
            return;
        }

        Usuario novoUsuario = new Usuario(nome, cpf);
        this.usuarios.add(novoUsuario);
        System.out.println("Usuário " + nome + " criado com sucesso!");
    }

    private void criarConta() {
        System.out.print("Digite o CPF do titular: ");
        String cpf = scanner.nextLine();
        Usuario titular = buscarUsuarioPorCPF(cpf);

        if (titular == null) {
            System.out.println("Erro: Usuário com CPF " + cpf + " não encontrado.");
            return;
        }

        System.out.print("Digite o número da nova conta: ");
        String numeroConta = scanner.nextLine();
        if (buscarContaGlobal(numeroConta) != null) {
            System.out.println("Erro: Número de conta já existente.");
            return;
        }

        System.out.print("Digite o tipo da conta (Ex: Corrente, Poupança): ");
        String tipoConta = scanner.nextLine();

        ContaBancaria novaConta = new ContaBancaria(numeroConta, tipoConta);
        titular.adicionarConta(novaConta);
        System.out.println("Conta " + tipoConta + " " + numeroConta + " criada para " + titular.getNome());
    }

    private ContaBancaria solicitarEBuscarConta() {
        System.out.print("Digite o número da conta: ");
        String numeroConta = scanner.nextLine();
        ContaBancaria conta = buscarContaGlobal(numeroConta);

        if (conta == null) {
            System.out.println("Erro: Conta " + numeroConta + " não encontrada.");
            return null;
        }
        return conta;
    }
    private void realizarDeposito() {
        ContaBancaria conta = solicitarEBuscarConta();
        if (conta != null) {
            try {
                System.out.print("Digite o valor a depositar: ");
                double valor = Double.parseDouble(scanner.nextLine());
                if (conta.depositar(valor)) {
                    System.out.println("Depósito realizado com sucesso.");
                } else {
                    System.out.println("Erro: Valor de depósito inválido.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Valor inválido. Digite um número.");
            }
        }
    }
    private void realizarSaque() {
        ContaBancaria conta = solicitarEBuscarConta();
        if (conta != null) {
            try {
                System.out.print("Digite o valor a sacar: ");
                double valor = Double.parseDouble(scanner.nextLine());
                if (conta.sacar(valor)) {
                    System.out.println("Saque realizado com sucesso.");
                } else {
                    System.out.println("Erro: Saldo insuficiente ou valor inválido.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Valor inválido. Digite um número.");
            }
        }
    }
    private void consultarExtrato() {
        ContaBancaria conta = solicitarEBuscarConta();
        if (conta != null) {
            conta.consultarExtrato();
        }
    }

    private void listarContasPorCPF() {
        System.out.print("Digite o CPF do usuário: ");
        String cpf = scanner.nextLine();
        Usuario titular = buscarUsuarioPorCPF(cpf);

        if (titular == null) {
            System.out.println("Nenhum usuário encontrado com o CPF: " + cpf);
            return;
        }
        System.out.println("\n--- CONTAS DO CLIENTE: " + titular.getNome() + " (CPF: " + cpf + ") ---");
        ArrayList<ContaBancaria> contas = titular.getContas();
        if (contas.isEmpty()) {
            System.out.println("Nenhuma conta encontrada para este usuário.");
        } else {
            for (ContaBancaria c : contas) {
                System.out.println(c);
            }
        }
    }
    private void listarTodasContas() {
        System.out.println("\n--- LISTA DE TODAS AS CONTAS DO BANCO ---");
        if (usuarios.isEmpty()) {
            System.out.println("Nenhum usuário cadastrado.");
            return;
        }
        int totalContas = 0;
        for (Usuario u : usuarios) {
            for (ContaBancaria c : u.getContas()) {
                System.out.println(c + " (Titular: " + u.getNome() + ")");
                totalContas++;
            }
        }
        if (totalContas == 0) {
            System.out.println("Nenhuma conta cadastrada no banco.");
        }
    }
    public static void main(String[] args) {
        BancoTerminal banco = new BancoTerminal();
        banco.exibirMenu();
    }
}