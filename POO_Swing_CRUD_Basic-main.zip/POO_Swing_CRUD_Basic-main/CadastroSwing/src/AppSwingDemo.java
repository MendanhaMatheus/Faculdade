import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AppSwingDemo extends JFrame {

    public AppSwingDemo() {
        setTitle("Aplicação de Cadastro - Java Swing");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel painelPrincipal = new JPanel(new BorderLayout());
        add(painelPrincipal);

        JMenuBar menuBar = new JMenuBar();
        JMenu menuArquivo = new JMenu("Arquivo");
        JMenuItem itemSair = new JMenuItem("Sair");
        itemSair.addActionListener(e -> System.exit(0));
        menuArquivo.add(itemSair);
        menuBar.add(menuArquivo);
        setJMenuBar(menuBar);

        JPanel painelSuperior = new JPanel(new FlowLayout());
        JLabel lblTitulo = new JLabel("Demonstração de Componentes Swing");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        painelSuperior.add(lblTitulo);
        painelPrincipal.add(painelSuperior, BorderLayout.NORTH);

        JPanel painelCentral = new JPanel();
        painelCentral.setLayout(new GridLayout(6, 2, 5, 5));

        painelCentral.add(new JLabel("Nome:"));
        JTextField txtNome = new JTextField();
        painelCentral.add(txtNome);

        painelCentral.add(new JLabel("Gênero:"));
        String[] generos = {"Masculino", "Feminino", "Outro"};
        JComboBox<String> cbGenero = new JComboBox<>(generos);
        painelCentral.add(cbGenero);

        painelCentral.add(new JLabel("Preferência:"));
        JCheckBox chkEmail = new JCheckBox("Receber e-mails");
        painelCentral.add(chkEmail);

        painelCentral.add(new JLabel("Tipo de usuário:"));
        JPanel painelRadios = new JPanel();
        JRadioButton rbAluno = new JRadioButton("Aluno XPTO");
        JRadioButton rbProfessor = new JRadioButton("Professor XPTO");
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(rbAluno);
        grupo.add(rbProfessor);
        painelRadios.add(rbAluno);
        painelRadios.add(rbProfessor);
        painelCentral.add(painelRadios);

        painelCentral.add(new JLabel("Comentários:"));
        JTextArea txtComentarios = new JTextArea(3, 20);
        painelCentral.add(new JScrollPane(txtComentarios));

        String[] colunas = {"Nome", "Gênero", "Tipo"};
        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);
        JTable tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);

        JPanel painelConteudo = new JPanel();
        painelConteudo.setLayout(new BoxLayout(painelConteudo, BoxLayout.Y_AXIS));
        painelConteudo.add(painelCentral);
        painelConteudo.add(scrollTabela);

        painelPrincipal.add(painelConteudo, BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel();
        JButton btnSalvar = new JButton("Adicionar");
        JButton btnLimpar = new JButton("Limpar Campos");
        JButton btnRemover = new JButton("Remover Selecionado"); // Botão 'Remover' adicionado

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnLimpar);
        painelBotoes.add(btnRemover); // Adiciona o botão 'Remover' ao painel
        painelPrincipal.add(painelBotoes, BorderLayout.PAGE_END);

        btnSalvar.addActionListener((ActionEvent e) -> {
            String nome = txtNome.getText();
            String genero = (String) cbGenero.getSelectedItem();
            String tipo = rbAluno.isSelected() ? "Aluno" :
                    rbProfessor.isSelected() ? "Professor" : "Não informado";

            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Por favor, informe o nome.",
                        "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return;
            }

            modelo.addRow(new Object[]{nome, genero, tipo});
            JOptionPane.showMessageDialog(this, "Registro adicionado com sucesso!");
            txtNome.setText(""); // Limpa o campo nome após adicionar
            cbGenero.setSelectedIndex(0);
            grupo.clearSelection();
            chkEmail.setSelected(false);
            txtComentarios.setText("");
        });

        btnLimpar.addActionListener(e -> {
            txtNome.setText("");
            cbGenero.setSelectedIndex(0);
            grupo.clearSelection();
            chkEmail.setSelected(false);
            txtComentarios.setText("");
        });

        // NOVO: ActionListener para o botão Remover Selecionado
        btnRemover.addActionListener(e -> {
            int linhaSelecionada = tabela.getSelectedRow(); // Obtém o índice da linha selecionada

            if (linhaSelecionada == -1) { // Verifica se alguma linha foi selecionada
                JOptionPane.showMessageDialog(this,
                        "Por favor, selecione uma linha para remover.",
                        "Nenhuma Linha Selecionada", JOptionPane.WARNING_MESSAGE);
            } else {
                // Exibe uma caixa de diálogo de confirmação
                int confirmacao = JOptionPane.showConfirmDialog(this,
                        "Tem certeza que deseja remover o registro selecionado?",
                        "Confirmar Remoção",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if (confirmacao == JOptionPane.YES_OPTION) { // Se o utilizador confirmar
                    modelo.removeRow(linhaSelecionada); // Remove a linha do modelo da tabela
                    JOptionPane.showMessageDialog(this, "Registro removido com sucesso!");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AppSwingDemo().setVisible(true));
    }
}