import java.util.Scanner;
public class CalculoMoeda extends Calculo implements Exibivel
{

    private double valorOriginal;
    private double cotacao;
    private double valorConvertido;
    private String moedaOrigem;
    private String moedaDestino;
    @Override
    public void executar()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("--- Conversor de Moedas ---");
        System.out.print("Digite a moeda de origem (ex: Real): ");
        this.moedaOrigem = scanner.nextLine();
        System.out.print("Digite a moeda de destino (ex: Dolar): ");
        this.moedaDestino = scanner.nextLine();
        System.out.print("Digite o valor em " + this.moedaOrigem + " a ser convertido: ");
        this.valorOriginal = scanner.nextDouble();
        System.out.print("Digite a cotação atual (Quanto 1 " + this.moedaOrigem + " vale em " + this.moedaDestino + "): ");
        this.cotacao = scanner.nextDouble();
        this.valorConvertido = this.valorOriginal * this.cotacao;
    }
    @Override
    public void exibirResultado()
    {
        System.out.println("--- Resultado da Conversão ---");
        System.out.println("Valor Original: " + String.format("%.2f", this.valorOriginal) + " (" + this.moedaOrigem + ")");
        System.out.println("Cotação: 1 " + this.moedaOrigem + " = " + this.cotacao + " " + this.moedaDestino);
        System.out.println("---------------------------------");
        System.out.println("Valor Convertido: " + String.format("%.2f", this.valorConvertido) + " (" + this.moedaDestino + ")");
    }
}