public abstract class Calculo
{
    public abstract void executar();

}