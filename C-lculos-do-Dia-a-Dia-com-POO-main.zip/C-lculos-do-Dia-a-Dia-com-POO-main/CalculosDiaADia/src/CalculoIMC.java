public class CalculoIMC extends Calculo implements Exibivel
{
    private double peso;
    private double altura;
    private double imcResultado;
    @Override
    public void executar()
    {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.println("--- Cálculo de IMC ---");
        System.out.print("Digite seu peso (em kg, ex: 70.5): ");
        this.peso = scanner.nextDouble();
        System.out.print("Digite sua altura (em m, ex: 1.75): ");
        this.altura = scanner.nextDouble();
        this.imcResultado = this.peso / (this.altura * this.altura);
    }

    @Override
    public void exibirResultado()
    {
        System.out.println("Seu IMC é: " + String.format("%.2f", this.imcResultado));
        if (this.imcResultado < 18.5)
        {
            System.out.println("Classificação: Abaixo do peso");
        }
        else if (this.imcResultado < 24.9)
        {
            System.out.println("Classificação: Peso normal");
        }
        else if (this.imcResultado < 29.9)
        {
            System.out.println("Classificação: Sobrepeso");
        }
        else
        {
            System.out.println("Classificação: Obesidade");
        }
    }
}