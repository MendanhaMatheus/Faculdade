import java.util.ArrayList;
import java.util.List;
public class Main
{
    public static void main(String[] args)
    {
        List<Calculo> meusCalculos = new ArrayList<>();
        meusCalculos.add(new CalculoIMC());
        meusCalculos.add(new CalculoSalario());
        meusCalculos.add(new CalculoMoeda());
        System.out.println("--- BEM-VINDO À CENTRAL DE CÁLCULOS ---");
        System.out.println("Encontrámos " + meusCalculos.size() + " cálculos para executar.");
        for (Calculo calc : meusCalculos)
        {
            System.out.println("\n==========================================");
            System.out.println("A iniciar: " + calc.getClass().getSimpleName());
            calc.executar();
            if (calc instanceof Exibivel) {
                Exibivel ex = (Exibivel) calc;
                ex.exibirResultado();
            }
        }
        System.out.println("\n==========================================");
        System.out.println("--- Todos os cálculos foram concluídos! ---");
    }
}