import java.util.Scanner;
public class CalculoSalario extends Calculo implements Exibivel
{
    private double salarioBruto;
    private double descontos;
    private double beneficios;
    private double salarioLiquido;
    @Override
    public void executar()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("--- Cálculo de Salário Líquido ---");
        System.out.print("Digite o salário bruto: ");
        this.salarioBruto = scanner.nextDouble();
        System.out.print("Digite o total de descontos (ex: INSS, IR): ");
        this.descontos = scanner.nextDouble();
        System.out.print("Digite o total de benefícios (ex: Vale Alimentação): ");
        this.beneficios = scanner.nextDouble();
        this.salarioLiquido = (this.salarioBruto - this.descontos) + this.beneficios;
    }

    @Override
    public void exibirResultado()
    {
        System.out.println("--- Folha de Pagamento ---");
        System.out.println("Salário Bruto: R$ " + String.format("%.2f", this.salarioBruto));
        System.out.println("Total Descontos: R$ " + String.format("%.2f", this.descontos));
        System.out.println("Total Benefícios: R$ " + String.format("%.2f", this.beneficios));
        System.out.println("---------------------------------");
        System.out.println("Salário Líquido a Receber: R$ " + String.format("%.2f", this.salarioLiquido));
    }
}